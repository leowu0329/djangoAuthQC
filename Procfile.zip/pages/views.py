from django.shortcuts import render
from django.views.generic import TemplateView
from django.contrib.auth.decorators import login_required

@login_required  # 這個裝飾器會自動檢查登入狀態
def home_page(request):
    return render(request, 'home.html')  # 假設你的首頁模板是 home.html

@login_required
def ipqc_list_view(request):
    return render(request, 'app/ipqc/ipqc_list.html')

@login_required
def defect_list_view(request):
    return render(request, 'app/ipqc/defect_list.html')

@login_required
def operator_list_view(request):
    return render(request, 'app/ipqc/operator_list.html')

@login_required
def order_list_view(request):
    return render(request, 'app/ipqc/order_list.html')

@login_required
def spec_list_view(request):
    return render(request, 'app/ipqc/spec_list.html')
